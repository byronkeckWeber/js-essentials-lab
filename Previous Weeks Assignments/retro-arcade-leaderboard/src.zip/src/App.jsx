import NewScoreForm from './components/NewScoreForm';
import LeaderboardList from './components/LeaderboardList';
import { useState } from 'react'
import './App.css'

  const INITIAL_SCORES = [
  { 
    id: "s1", 
    playerInitials: "PAC", 
    gameTitle: "Pac-Man", 
    score: 3333360,
    category: "Arcade Classic"
  },
  { 
    id: "s2", 
    playerInitials: "MAR", 
    gameTitle: "Donkey Kong", 
    score: 1260700,
    category: "Arcade Classic"
  },
  { 
    id: "s3", 
    playerInitials: "ACE", 
    gameTitle: "Galaga", 
    score: 1599100,
    category: "Sci-Fi Shooter"
  }
];
function App() {
  const [highScores, setScores] = useState(INITIAL_SCORES);

  const addHighScoreHandler = (highScore) => {
    setScores((prevScores) => [highScore, ...prevScores]);
  };
  


  return (
    <div>
      <h1>Retro Leaderboard</h1>
      <NewScoreForm onAddScore={addHighScoreHandler}/>
      <LeaderboardList items = {highScores}/>
    </div>
    
  );
}

export default App

/*
1. Controlled Input Form (NewScoreForm.jsx)
2. High Score List & Item Display (LeaderboardList.jsx & ScoreCard.jsx):
3. Filter Controls (CategoryFilter.jsx)
4. Derived Summary Stats (ScoreSummary.jsx)

5. Central State Management & Event Flow (App.jsx):
In App.jsx:
Initialize state for the list of scores using useState(INITIAL_SCORES)
and state for the category filter.
Implement an event handler function to add new entries using a functional state 
update and spread syntax (i.e., setScores((prevScores) => [newEntry, ...prevScores])).
Derive the filtered array of scores based on the current category state
 and pass down the filtered list to LeaderboardList and ScoreSummary.
*/