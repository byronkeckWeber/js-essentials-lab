function ScoreCard(props) {
    return (
        <div className="card">
            <h4>{props.initials}</h4>
            <p>Game Title: {props.title}</p>
            <p>High Score: {props.highScore.toLocaleString()}</p>
            <p>Category: {props.category}</p>
        </div>
    );
}

export default ScoreCard;

/*
2. High Score List & Item Display (LeaderboardList.jsx & ScoreCard.jsx):
Create a ScoreCard.jsx component to format individual entry cards and a LeaderboardList.jsx component to display the collection.
Use .map() to render each score item dynamically, ensuring every rendered element receives a unique key prop (i.e., score.id).
*/