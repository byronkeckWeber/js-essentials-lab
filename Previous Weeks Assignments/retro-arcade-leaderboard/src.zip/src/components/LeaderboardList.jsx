import ScoreCard from "./ScoreCard";
import CategoryFilter from "./CategoryFilter";
import ScoreSummary from "./ScoreSummary";
import { useState } from "react";

function LeaderboardList(props) {

    const [filterCategory, setFilterCategory] = useState('All');

    const filterChangeHandler = (selectedCategory) => {
        setFilterCategory(selectedCategory);
    }

    const filteredHighScores = props.items.filter((highScore) => {
        if (filterCategory === 'All')
            return true;
        return highScore.category === filterCategory;
    });

    return (
        <div className="card">
            <h2>Leaderboard</h2>
            
            <CategoryFilter onChangeFilter={filterChangeHandler}/>

            <ScoreSummary items = {filteredHighScores} category = {filterCategory} />


            {filteredHighScores.length === 0 ? (
                <p>No Highscores for this category yet.</p>

            ) : ( 

                filteredHighScores.map((highScore) => (
                    <ScoreCard
                    key={highScore.id}
                    initials={highScore.playerInitials}
                    title={highScore.gameTitle}
                    highScore={highScore.score}
                    category={highScore.category} />
            )))}
        </div>
    );
}

export default LeaderboardList;

/*
a LeaderboardList.jsx component to display the collection.
2. High Score List & Item Display (LeaderboardList.jsx & ScoreCard.jsx):
Create a ScoreCard.jsx component to format individual entry cards and a LeaderboardList.jsx component to display the collection.
Use .map() to render each score item dynamically, ensuring every rendered element receives a unique key prop (i.e., score.id).
*/