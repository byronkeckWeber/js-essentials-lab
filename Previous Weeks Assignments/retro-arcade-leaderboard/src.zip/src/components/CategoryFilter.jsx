function CategoryFilter(props) {

    const dropdownChangeHandler = (event) => {
        props.onChangeFilter(event.target.value);
    }

    return (
        <div>
            <label>Filter by Category</label>
            <select onChange={dropdownChangeHandler} value={props.selected}>
                <option value="All">All Categories</option>
                <option value="Arcade Classic">Arcade Classic</option>
                <option value="Sci-Fi Shooter">Sci-Fi Shooter</option>
                <option value="Indie Title">Indie Title</option>
                <option value="Adventure Game">Adventure Game</option>
            </select>
        </div>
    );
}

export default CategoryFilter;

/*
3. Filter Controls (CategoryFilter.jsx):
Create a CategoryFilter.jsx component containing a dropdown/select control for filtering entries by category (or "All Categories").
Lift the selected filter state up to App.jsx so filtering affects both the rendered list and summary statistics.
*/